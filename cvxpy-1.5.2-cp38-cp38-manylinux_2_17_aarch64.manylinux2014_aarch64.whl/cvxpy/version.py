
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.5.2'
version = '1.5.2'
full_version = '1.5.2'
git_revision = '7d24ec6'
commit_count = '0'
release = True
if not release:
    version = full_version
